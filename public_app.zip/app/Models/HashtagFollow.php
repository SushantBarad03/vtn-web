<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HashtagFollow extends Model
{
    use HasFactory;

    protected $table ='follow_hashtag';
}
